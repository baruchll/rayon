﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rayon
{
    class Class1
    {
        public string name { get; set; }
        public string tz { get; set; }

        public string kaba { get; set; }

        public string dapr { get; set; }

        public string bagrut { get; set; }
    }
}
